import React, { useState } from 'react';
import { ZMenu, ZButton, ZLogo, ZDrawer } from 'zitics-core-ui';
import AddCommentDrawer from '../CommentsDrawer'; // Ensure the path is correct
import { useParams } from 'react-router-dom';
import { infoIcon } from '../../../../../../assets/Images';


interface CommentButtonProps {
  fieldName: string; // Define the fieldName prop type
}

const CommentButton: React.FC<CommentButtonProps> = ({ fieldName }) => {
  const [isLocalDrawerOpen, setIsLocalDrawerOpen] = useState(false);
  const { proposalId } = useParams(); // Get proposalId from the URL

  return (
    <>
      {/* Menu trigger for adding comments */}
      <ZMenu
        items={[
          {
            key: 'addComment',
            content: 'Add Comments',
            onClick: () => setIsLocalDrawerOpen(true), // Open the drawer
          },
        ]}
        menuTrigger={
          <ZButton style={{background:'transparent' , display:'flex' , justifyContent:'flex-start'}}>
            <ZLogo src={infoIcon} />
          </ZButton>
        }
      />

      {/* Drawer to display the AddCommentDrawer component */}
      <ZDrawer
        open={isLocalDrawerOpen}
        setIsOpen={setIsLocalDrawerOpen}
        title={`Comments - ${fieldName}`} // Dynamic title based on fieldName
      >
        {/* Render AddCommentDrawer if proposalId is available */}
        {proposalId && (
          <AddCommentDrawer
            fieldName={fieldName}
            proposalId={proposalId}
            setOpen={setIsLocalDrawerOpen}
          />
        )}
      </ZDrawer>
    </>
  );
};

export default CommentButton;