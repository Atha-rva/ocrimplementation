import { colorSchema, makeStyles } from "zitics-core-ui";

export const useStyles = makeStyles({
    outerContainer:{
        padding:"1rem"
    },
    mainContainer:{
        marginBottom: "1rem" 
    },
  commentsContainer: {
    display: "flex",
    flexDirection: "column",
    wordWrap: "break-word",
    padding: "0.75rem",
    background: `${colorSchema.grays.defaultBackground}`,
    borderRadius: "0.5rem",
    boxShadow: "0 0.125rem 0.25rem rgba(63, 18, 18, 0.1)",
    width:'100%'
  },
  timeStampContainer: {
    display: "flex",
    fontSize: "0.625rem",
    color: `${colorSchema.grays.TertiaryText}`,
    marginBottom: "0.5rem",
    justifyContent: "flex-end",
  },
  dividerClass: {
    border: "none",
  },
  bottomContainer: {
    position: "fixed",
    bottom: "5.625rem",
    left: "50%",
    transform: "translateX(-51%)",
    width: "90%",
    background: `${colorSchema.grays.defaultBackgroundOutline}`,
  },
  inputClass:{
    width: "100%",
    height: "6.25rem",
    padding: "0.5rem",
    marginBottom: "1rem",
    borderRadius: "0.25rem",
  },
  buttonClass:{
    cursor: "pointer",
    width: "100%",
  },
  error:{
    color:'red'
  }
});
