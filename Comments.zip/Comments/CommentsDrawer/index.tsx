// import React, { useState } from "react";
// import { v4 as uuidv4 } from "uuid"; // Import uuid
// import { colorSchema, ZButton, ZDivider, ZTextarea } from "zitics-core-ui";
// import { useStyles } from "./Styles";

// interface UpdateFinancialProps {
//   setOpen: React.Dispatch<React.SetStateAction<boolean>>;
//   fieldName?: string;
// }

// interface Comment {
//   id: string; // Add id field
//   text: string;
//   timestamp: string;
// }

// const AddCommentDrawer: React.FC<UpdateFinancialProps> = ({ setOpen }) => {
//   const [comment, setComment] = useState(""); // State to store the comment input
//   const [comments, setComments] = useState<Comment[]>([]); // State to store all comments

//   const styles = useStyles();

//   const handleAddComment = () => {
//     if (!comment.trim()) {
//       alert("Please enter a comment."); // Validation to ensure the comment is not empty
//       return;
//     }

//     // Create a new comment object with id, text, and timestamp
//     const newComment = {
//       id: uuidv4(), // Generate a unique ID using uuid
//       text: comment,
//       timestamp: new Date().toLocaleString(), // Get current date and time
//     };

//     // Add the new comment to the beginning of the list of comments
//     setComments((prevComments) => [newComment, ...prevComments]);

//     // Clear the input field
//     setComment("");
//   };

//   return (
//     <div className={styles.outerContainer}>
//       {/* Display existing comments with timestamps */}
//       <div className={styles.mainContainer}>
//         {comments.map((comment) => (
//           <div key={comment.id}> {/* Use comment.id as the key */}
//             <div className={styles.commentsContainer}>
//               {comment.text}
//             </div>
//             <div className={styles.timeStampContainer}>
//               {comment.timestamp}
//             </div>
//             {/* Divider after each comment */}
//             {comments.indexOf(comment) !== comments.length - 1 && (
//               <ZDivider
//                 className={styles.dividerClass}
//               />
//             )}
//           </div>
//         ))}
//       </div>

//       {/* Textarea and button container */}
//       <div className={styles.bottomContainer}>
//         <ZTextarea
//           value={comment}
//           onChange={(e: any) => setComment(e.target.value)} // Update the comment state
//           placeholder="Enter your comment here..."
//         />

//         {/* Button to add a new comment */}
//         <ZButton
//           onClick={handleAddComment}
//           className={styles.buttonClass}
//         >
//           Add Comment
//         </ZButton>
//       </div>
//     </div>
//   );
// };

// export default AddCommentDrawer;
import React, { useState, useEffect } from "react";
import { colorSchema, ZAvatar, ZButton, ZDivider, ZTextarea } from "zitics-core-ui";
import { useStyles } from "./Styles";
import { commentService } from "../services/commentService"; // Import the comment service
import { useParams } from "react-router-dom"; // To get the proposalId from the URL
import { useSelector } from "react-redux";

interface UpdateFinancialProps {
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
  fieldName?: string;
  proposalId?:string;
}

interface Comment {
  id: string; // Unique ID for each comment
  comment: string; // Comment text
  created_at: string; // Timestamp of the comment
}

const AddCommentDrawer: React.FC<UpdateFinancialProps> = ({ setOpen, fieldName }) => {
  const [comment, setComment] = useState(""); // State to store the comment input
  const [comments, setComments] = useState<Comment[]>([]); // State to store all comments
  const [loading, setLoading] = useState(true); // Loading state
  const [error, setError] = useState(""); // Error state

  const authUserData = useSelector((state: any) => {
    return state.userData;
  });


  const styles = useStyles();
  const { proposalId } = useParams(); // Get proposalId from the URL

  // Fetch comments when the component mounts
  useEffect(() => {
    if (!proposalId || !fieldName) return;

    const fetchComments = async () => {
      try {
        const data = await commentService.getComments(proposalId, fieldName);
        console.log("Fetched comments:", data); // Debugging
        setComments(data);
        setLoading(false);
      } catch (err) {
        console.error("Error fetching comments:", err); // Debugging
        setError("Failed to fetch comments");
        setLoading(false);
      }
    };

    fetchComments();
  }, [proposalId, fieldName]);

  // Handle adding a new comment
  const handleAddComment = async () => {
    if (!comment.trim()) {
      alert("Please enter a comment."); // Validation to ensure the comment is not empty
      return;
    }

    if (!proposalId || !fieldName) return;

    try {
      // Add the new comment to the backend
      const newComment = await commentService.addComment(proposalId, fieldName, comment);
      console.log("Added comment:", newComment); // Debugging

      // Add the new comment to the local state
      setComments((prevComments) => [newComment, ...prevComments]);

      // Clear the input field
      setComment("");
    } catch (err) {
      console.error("Error adding comment:", err); // Debugging
      setError("Failed to add comment");
    }
  };

  return (
    <div className={styles.outerContainer}>
      {/* Display existing comments with timestamps */}
      <div className={styles.mainContainer}>
        {loading ? (
          <div>Loading comments...</div>
        ) : error ? (
          <div className={styles.error}>{error}</div>
        ) : (
          comments.map((comment) => (
            <div style={{display:'flex' , gap:'10px'}}>
            <ZAvatar
            name={authUserData.firstName}
            status={"available"}
            // isAvatar={true}
            isName={false}
            showTooltip={true}
          />
            <div key={comment.id}>
              <div className={styles.commentsContainer}>
                {comment.comment}
              </div>
              <div className={styles.timeStampContainer}>
                {new Date(comment.created_at).toLocaleString()}
              </div>
              {/* Divider after each comment */}
              {/* {comments.indexOf(comment) !== comments.length - 1 && (
                <ZDivider className={styles.dividerClass} />
              )} */}
            </div>
            </div>
          ))
        )}
      </div>

      {/* Textarea and button container */}
      <div className={styles.bottomContainer}>
        <ZTextarea
          value={comment}
          onChange={(e: any) => setComment(e.target.value)} // Update the comment state
          placeholder="Enter your comment here..."
        />

        {/* Button to add a new comment */}
        <ZButton
          onClick={handleAddComment}
          className={styles.buttonClass}
        >
          Add Comment
        </ZButton>
      </div>
    </div>
  );
};

export default AddCommentDrawer;