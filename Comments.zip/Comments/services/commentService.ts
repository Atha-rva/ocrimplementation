const API_BASE = 'http://localhost:5000/api'; // Update with your backend URL

export const commentService = {
  // Fetch comments for a specific field
  getComments: async (proposalId: string, fieldName: string) => {
    try {
      const response = await fetch(`${API_BASE}/comments/${proposalId}/${fieldName}`);
      if (!response.ok) throw new Error('Failed to fetch comments');
      return response.json();
    } catch (error) {
      console.error('Error fetching comments:', error);
      throw error;
    }
  },

  // Add a new comment
  addComment: async (proposalId: string, fieldName: string, comment: string) => {
    try {
      const response = await fetch(`${API_BASE}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proposalId, fieldName, comment }),
      });
      if (!response.ok) throw new Error('Failed to add comment');
      return response.json();
    } catch (error) {
      console.error('Error adding comment:', error);
      throw error;
    }
  },
};